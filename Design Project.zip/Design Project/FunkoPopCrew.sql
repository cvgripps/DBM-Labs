-------------------------------------------------------------------------------
--Funko Pop Crew Database 
--Charles Grippaldi
--Alan Labouseur
--Design Project
--12/4/2017
--
--This is a database documenting the data for a group of Funko Pop! collectors
--who call themselves the Funko Pop Crew
-------------------------------------------------------------------------------


--Just in case!

drop table if exists Members;
drop table if exists Guests;
drop table if exists Meetings;
drop table if exists Venues;
drop table if exists F001;
drop table if exists F002;
drop table if exists F003;
drop table if exists F004;
drop table if exists F005;
drop table if exists F006;
drop table if exists F007;
drop table if exists Humans;
drop table if exists Pops cascade;

--Let's build those tables!

/*  Humans  */
create table Humans (
	hid          VARCHAR(4) not null,
	fName        TEXT,
	lName        TEXT,
	dob          DATE,
	address      TEXT,
	city         TEXT,
	state        TEXT,
	zip          INT,
	phoneNum     BIGINT,
	email        TEXT,
  primary key(hid)
);


/*  Members  */
create table Members(
	hid          VARCHAR(4) not null references humans(hid),
	boxPref      TEXT,
	firstPop     TEXT,
	favPop       TEXT,
  primary key(hid)
);


/*  Guests  */
create table Guests(
	hid          VARCHAR(4) not null references humans(hid),
	broughtByHID VARCHAR(4) not null references humans(hid),
	relation     TEXT,
  primary key(hid)
);


/*  Pops  */
create table Pops(
	pid          VARCHAR(6) not null,
	pName        TEXT,
	line         TEXT,
	lineNum      INT,
	title        TEXT,
	exclTo       TEXT not null,
	chase        BOOLEAN,
	gitd         BOOLEAN,
	flocked      BOOLEAN,
  primary key(pid)
);


/*  Venues  */
create table Venues(
	vid          VARCHAR(4) not null,
	vName        TEXT,
	vAddress     TEXT,
	vCity        TEXT,
	vState       TEXT,
	vZip         INT,
	vPhoneNum    BIGINT,
  primary key(vid)
);


/*  Meetings  */
create table Meetings(
	whenMeet      TIMESTAMP not null,
	vid           VARCHAR(4) not null references venues(vid),
	meetLeaderHID VARCHAR(4) not null references humans(hid),
	numAttended  INT,
	topics       TEXT,
  primary key(whenMeet)	
);




--The following tables represent members' collections
--These are identified buy HID's

/* F001 Charlie Grippaldi */
create table F001(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F002 Alan Labouseur */
create table F002(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F003 Dan Tucci */
create table F003(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F004 Jake White */
create table F004(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F005 Evan Fernandez */
create table F005(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F006 Joey Grippaldi */
create table F006(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);


/* F007 Eric Anderson */
create table F007(
	pid          VARCHAR(6) not null references pops(pid),
	purchPrice   MONEY,
	boxCond	     TEXT,
	purchDate DATE,
	qty          INT,
  primary key(pid)
);



--Time to insert data into those tables!

/*  Pops 		Data  */

insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('8B0030', 'Dig Dug', '8-Bit', 003, 'Dig Dug', 
			'2017 Fall Convention', false, false, false);

insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN0551','Zoidberg', 'Animation', 055, 'Futurama',
            'Hot Topic', true, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN1020', 'Beefsquatch', 'Animation', 102, 'Bobs Burgers',
            'None', false, false, false);

insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN2280', 'BoJack Horseman', 'Animation', 228, 'BoJack Horseman',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN2240', 'Krumm', 'Animation', 224, 'AAAHHH!!! Real Monsters',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN0510', 'Lucy Van Pelt', 'Animation', 051, 'Peanuts',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN1770', 'Mr. Poopy Butthole', 'Animation', 177, 'Rick and Morty',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN2270', 'Reptar', 'Animation', 227, 'Rugrats',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('AN2320', 'Todd Chavez', 'Animation', 232, 'BoJack Horseman',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('BK0052', 'Sam I Am', 'Books', 005, 'Dr. Seuss',
            'Barnes and Noble', false, false, true);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA2260', 'Baby', 'Games', 226, 'FNaF Sister Location',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA2170', 'Balloon Boy', 'Games', 217, 'Five Nights at Freddys',
            'Walmart', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA2430', 'Chell', 'Games', 243, 'Portal 2',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA1080', 'Chica', 'Games', 108, 'Five Nights at Freddys',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA1062', 'Freddy', 'Games', 106, 'Five Nights at Freddys',
            'Barnes and Noble', false, false, true);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA2230', 'Jumpscare Funtime Foxy', 'Games', 223, 'FNaF Sister Location',
            '2017 Summer Convention', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA2150', 'Nightmare Bonnie', 'Games', 215, 'Five Nights at Freddys',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('GA1103', 'Springtrap', 'Games', 110, 'Five Nights at Freddys',
            'Game Stop', false, true, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('MN0060', 'Picklez', 'Monsters', 006, 'Funko',
            'Funko Shop', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('RI0020', 'Time Machine', 'Rides', 002, 'Back to the Future',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('RK0290', 'George Harrison', 'Rocks', 029, 'The Beatles Yellow Submarine',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('RK0410', 'Black Parade Gerard Way', 'Rocks', 041, 'My Chemical Romance',
            'Hot Topic', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('SP0060', 'Mint-Berry Crunch', 'South Park', 006, 'South Park',
            '2017 Summer Convention', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('SP0080', 'Stan', 'South Park', 008, 'South Park',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV5020', 'April Ludgate', 'Television', 502, 'Parks and Recreation',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV4320', 'Erlich', 'Television', 432, 'Silicon Valley',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV5520', 'Max (Costume)', 'Television', 552, 'Stranger Things',
            'Hot Topic', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV5140', 'Nancy', 'Television', 514, 'Stranger Things',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV4310', 'Richard', 'Television', 431, 'Silicon Valley',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title, 
				 exclTo, chase, gitd, flocked)
	values ('TV4990', 'Ron Swanson', 'Television', 499, 'Parks and Recreation',
            'None', false, false, false);
			
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SW1930', 'Luke Skywalker', 'Star Wars', 193, 'Star Wars',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SW0010', 'Darth Vader', 'Star Wars', 001, 'Star Wars',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SW0310', 'R2-D2', 'Star Wars', 031, 'Star Wars',
           'None', false, false, false);
   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MV5180', 'James Bond from Goldfinger', 'Movies', 518, '007',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MV5260', 'Oddjob from Goldfinger Throwing Hat', 'Movies', 526, '007',
           'Target', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('GA2440', 'Turret', 'Games', 244, 'Portal 2',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV0820', 'Spock', 'Television', 082, 'Star Trek',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('8B0270', 'Xenomorph', '8-Bit', 027, 'Alien',
           'Previews', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MV2360', 'Dr. Emmett Brown 1955 w/ Jumper Cables', 'Movies', 236, 'Back to the Future',
           'Loot Crate', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AN1220', 'Space Ghost', 'Animation', 122, 'Space Ghost',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AI0030', 'Boo Berry', 'Ad Icons', 003, 'General Mills',
           'Funko Shop', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AN1400', 'Doofus Rick', 'Animation', 140, 'Rick and Morty',
           'Game Stop', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SL0010', 'Stan Lee (Nuff Said)', 'Stan Lee', 001, 'Stan Lee',
           'MegaCon', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SW0610', 'BB-8', 'Star Wars', 061, 'Star Wars',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV4281', 'Demogorgon', 'Television', 428, 'Stranger Things',
           'None', true, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV4211', 'Eleven w/ Eggos', 'Television', 421, 'Stranger Things',
           'None', true, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV4750', 'Steve', 'Television', 475, 'Stranger Things',
           'San Diego Comic Con', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MA0230', 'Iron Man (Iron Man 3)', 'Marvel', 023, 'Iron Man 3',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('GA0920', 'Tracer', 'Games', 092, 'Overwatch',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('DI1371', 'Bing Bong', 'Disney', 137, 'Inside Out',
           'Hot Topic', true, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AN1650', 'Stimpy', 'Animation', 165, 'Ren and Stimpy',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MV3811', 'Conan the Barbarian', 'Movies', 381, 'Conan the Barbarian',
           'Previews', true, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('HR1590', 'Red Sonja', 'Heroes', 158, 'Red Sonja',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AN0440', 'Cobra Commander', 'Animation', 044, 'GI Joe',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('AN0420', 'Snake Eyes', 'Animation', 042, 'GI Joe',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('HR1010', 'Boomerang', 'Heroes', 101, 'Suicide Squad',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('HR0160', 'Aquaman', 'Heroes', 016, 'DC Universe',
           'Previews', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV0600', 'Donatello', 'Television', 060, 'Teenage Mutant Ninja Turtles',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('TV0630', 'Leonardo', 'Television', 063, 'Teenage Mutant Ninja Turtles',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('HR1840', 'The Penguin', 'Heroes', 184, 'Batman',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MA0480', 'Rocket Raccoon', 'Marvel', 048, 'Guardians of the Galaxy',
           'None', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MA0190', 'Silver Surfer', 'Marvel', 019, 'Marvel Universe',
           'None', false, false, false);
		   

insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SW0080', 'Boba Fett (Prototype Armor)', 'Star Wars', 008, 'Star Wars',
           'Walgreens', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('MA1000', 'Anti-Venom', 'Marvel', 100, 'Marvel',
           'Hot Topic', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('HR0060', 'The Joker (Black Suit)', 'Heroes', 006, 'DC Super Heroes',
           'Walgreens', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('SL0020', 'Stan Lee (San Diego Comic Con)', 'Stan Lee', 002, 'Stan Lee Convention Exclusive',
           'San Diego Comic Con', false, false, false);
		   
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('GA0533', 'Vault Boy', 'Games', 053, 'Fallout',
           'Hot Topic', false, true, false);
		 
insert into Pops(pid, pName, line, lineNum, title,
                 exclTo, chase, gitd, flocked)
	values('GA0490', 'Power Armor (Brotherhood of Steel)', 'Games', 049, 'Fallout',
           'None', false, false, false);
		 
		 
		 
	
/*  Humans Data */

insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F001', 'Charlie', 'Grippaldi', date '1997-01-06',
	        '19 Poplar St', 'Poughkeepsie', 'NY', 12601,
			5163605753, 'southpawxd@gmail.com');
			
--Sorry, about to fudge some data that I don't know about you!
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F002', 'Alan', 'Labouseur', date '1970-07-12',
	        '3399 North Rd', 'Poughkeepsie', 'NY', 12601,
			8454902733, 'Alan.Labouseur@marist.edu');
			
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F003', 'Dan', 'Tucci', date '1998-12-20',
	        '451 Armstrong Rd', 'New Haven', 'CT', 90132,
			7187536612, 'Tucci99@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F004', 'Jake', 'White', date '1998-04-20',
	        '84 Bennington Ct', 'Franklin Sq', 'NY', 11010,
			5165557820, 'jawman@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F005', 'Evan', 'Fernandez', date '1997-10-17',
	        '42 Morrison St', 'Poughkeepsie', 'NY', 12601,
			8457576996, 'marvelman@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F006', 'Joey', 'Grippaldi', date '2010-05-24',
	        '2000 Millennium St', 'Franklin Sq', 'NY', 11010,
			5161236789, 'greenboy@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
                   address, city, state, zip,
				   phoneNum, email)
	values ('F007', 'Eric', 'Anderson', date '1993-01-06',
	        '4011 Charles St', 'Bridgeport', 'CT', 06606,
			2031774747, 'oldenough@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
				   address, city, state, zip,
				   phoneNum, email)
	values ('F008', 'Peter', 'Parker', date '1987-05-01',
			'4997 28th Ave', 'New York', 'NY', '98325',
			9174520503, 'friendlyspider@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
				   address, city, state, zip,
				   phoneNum, email)
	values ('F009', 'Bob', 'Newby', date '1972-03-27',
			'4016 Carukin St', 'Hawkins', 'IN', '12904',
			7883752294, 'rsnewby@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
				   address, city, state, zip,
				   phoneNum, email)
	values ('F010', 'Grayson', 'Hunt', date '1984-07-11',
			'16 Tennis Ct', 'Poughkeepsie', 'NY', '06606',
			8451015514, 'lonewolf@ymail.net');
			
insert into Humans(hid, fName, lName, dob,
				   address, city, state, zip,
				   phoneNum, email)
	values ('F011', 'Nelson', 'Bighetti', date '1991-02-02',
			'58 Hendricks Blvd', 'Palo Alto', 'CA', '19873',
			8884443333, 'bighead@ymail.net');

insert into Humans(hid, fName, lName, dob,
				   address, city, state, zip,
				   phoneNum, email)
	values ('F012', 'Gianna', 'Dangelo', date '1998-10-04',
			'77 Manning Drive', 'Franklin Square', 'NY', '11010',
			5162132016, 'cutie@ymail.net');
			

/*  Members Data */

insert into Members(hid, boxPref, firstPop, favPop)
	values ('F001', 'in', 'RK0290', 'RI0020');
	
insert into Members(hid, boxPref, firstPop, favPop)
	values ('F002', 'in', 'GA2430', 'MV5180');
	
insert into Members(hid, boxPref, firstPop, favPop)
	values ('F003', 'out', '8B0030', 'TV4320');

insert into Members(hid, boxPref, firstPop, favPop)
	values ('F004', 'in', 'SL0010', 'AN1220');

insert into Members(hid, boxPref, firstPop, favPop)
	values ('F005', 'in', 'HR0160', 'MA0480');

insert into Members(hid, boxPref, firstPop, favPop)
	values ('F006', 'out', 'SW1930', 'SW1930');

insert into Members(hid, boxPref, firstPop, favPop)
	values ('F007', 'out', 'None', 'None');


/* Guests Data */

insert into Guests(hid, broughtByHID, relation)
	values('F008', 'F001', 'Friend');
	
insert into Guests(hid, broughtByHID, relation)
	values('F009', 'F004', 'Uncle');
	
insert into Guests(hid, broughtByHID, relation)
	values('F010', 'F002', 'Friend');
	
insert into Guests(hid, broughtByHID, relation)
	values('F011', 'F006', 'Collegue');
	
insert into Guests(hid, broughtByHID, relation)
	values('F012', 'F001', 'Girlfriend');
	

	
/*  Here comes Members collection table data!  */


/*  F001 Charlie Grippaldi  */

insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('8B0030', 15.00, 'Mint', date '2017-11-05', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN0551', 5.00, 'Mint', date '2017-08-15', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN1020', 8.98, 'Mint', date '2017-10-21', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN2280', 0.00, 'Mint', date '2017-08-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN2240', 11.99, 'Mint', date '2017-10-21', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN0510', 5.00, 'None', date '2017-08-14', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN1770', 15.00, 'Mint', date '2017-05-18', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN2270', 9.95, 'Mint', date '2017-09-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('AN2320', 8.33, 'Mint', date '2017-11-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('BK0052', 11.95, 'Mint', date '2017-09-03', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2260', 9.95, 'Mint', date '2017-10-10', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2170', 3.98, 'Mint', date '2017-11-21', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2430', 9.00, 'Near Mint', date '2017-11-17', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA1080', 0.00, 'Mint', date '2017-07-22', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA1062', 12.95, 'Mint', date '2017-09-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2230', 15.00, 'Mint', date '2017-09-02', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2150', 9.00, 'Near Mint', date '2017-11-17', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('GA1103', 11.99, 'Very Good', date '2017-08-15', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('MN0060', 15.00, 'Mint', date '2017-11-01', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('RI0020', 30.99, 'Mint', date '2017-08-15', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('RK0290', 0.00, 'None', date '2017-06-24', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('RK0410', 27.50, 'Near Mint', date '2017-11-08', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('SP0060', 15.00, 'Mint', date '2017-08-04', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('SP0080', 8.33, 'Mint', date '2017-11-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV5020', 9.99, 'Mint', date '2017-10-19', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4320', 0.00, 'Mint', date '2017-10-21', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV5520', 9.00, 'Mint', date '2017-11-17', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV5140', 8.34, 'Mint', date '2017-11-23', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4310', 0.00, 'Mint', date '2017-08-08', 1);
	
insert into F001(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4990', 6.49, 'Mint', date '2017-08-19', 1);
	

/*  F002 Alan Labouseur  */
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('MV5260', 8.98, 'Near Mint', date '2017-12-19', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('MV5180', 11.99, 'Mint', date '2017-11-26', 2);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('SW0310', 9.75, 'Very Good', date '2015-01-06', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('SW0010', 10.00, 'Mint', date '2015-01-06', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2430', 5.00, 'Mint', date '2017-08-11', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('GA2440', 5.00, 'Mint', date '2017-08-11', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('TV0820', 26.00, 'None', date '2014-05-24', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('8B0270', 11.99, 'Near Mint', date '2017-12-01', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('RI0020', 34.00, 'Mint', date '2016-09-16', 1);
	
insert into F002(pid, purchPrice, boxCond, purchDate, qty)
	values('MV2360', 9.75, 'Good', date '2016-09-24', 2);
	

/*  F003 Dan Tucci  */

insert into F003(pid, purchPrice, boxCond, purchDate, qty)
	values('8B0030', 15.00, 'Mint', date '2017-11-05', 1);
	
insert into F003(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4320', 5.00, 'Good', date '2017-11-05', 1);
	
insert into F003(pid, purchPrice, boxCond, purchDate, qty)
	values('GA0533', 16.00, 'Mint', date '2016-03-28', 1);
	
insert into F003(pid, purchPrice, boxCond, purchDate, qty)
	values('GA0490', 9.98, 'Mint', date '2016-06-10', 1);
	
/*  F004  Jake White  */

insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('AN1220', 20.00, 'Mint', date '2015-02-15', 2);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('8B0030', 15.00, 'Mint', date '2017-11-07', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('AI0030', 23.68, 'Near Mint', date '2014-09-13', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('AN1400', 7.50, 'Very Good', date '2017-10-05', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('SL0010', 25.99, 'Mint', date '2015-05-17', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('SW0610', 11.99, 'Near Mint', date '2017-11-24', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4281', 15.00, 'Mint', date '2017-10-31', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4211', 10.99, 'Mint', date '2017-10-31', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('TV4750', 12.99, 'Mint', date '2017-11-22', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('MA0230', 7.00, 'Poor', date '2014-08-02', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('GA0920', 8.99, 'Near Mint', date '2016-01-19', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('DI1371', 15.00, 'Mint', date '2016-02-21', 1);
	
insert into F004(pid, purchPrice, boxCond, purchDate, qty)
	values('AN1650', 9.50, 'Mint', date '2017-09-15', 3);
	

/*  F005 Evan Fernandez  */

insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('MV3811', 8.95, 'Mint', date '2015-08-31', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('HR1590', 9.95, 'Near Mint', date '2016-03-24', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('AN0440', 9.99, 'Mint', date '2017-07-01', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('AN0420', 5.00, 'Good', date '2015-08-31', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('HR1010', 12.98, 'Mint', date '2017-09-09', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('HR0160', 9.00, 'Very Good', date '2016-05-18', 2);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('TV0600', 8.95, 'Near Mint', date '2016-04-03', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('TV0630', 8.95, 'Mint', date '2016-04-03', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('HR1840', 10.99, 'Mint', date '2017-08-31', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('MA0480', 9.95, 'Mint', date '2016-06-12', 2);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('MA0190', 15.00, 'Near Mint', date '2015-01-31', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('SW0080', 12.98, 'Mint', date '2014-03-13', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('MA1000', 11.95, 'Very Good', date '2013-07-29', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('HR0060', 8.98, 'Mint', date '2016-10-06', 1);
	
insert into F005(pid, purchPrice, boxCond, purchDate, qty)
	values('SL0020', 10.99, 'Mint', date '2017-08-07', 1);
	

/*  F006 Joey Grippaldi  */

insert into F006(pid, purchPrice, boxCond, purchDate, qty)
	values('SW0010', 9.99, 'None', date '2017-06-11', 1);
	
insert into F006(pid, purchPrice, boxCond, purchDate, qty)
	values('SW1930', 6.75, 'None', date '2015-09-14', 1);
	
/*  F007 Eric Anderson  */

/*
No data yet
New Collector

insert into F007(pid, purchPrice, boxCond, purchDate, qty)
	values('', , '', date '', );
	

*/


/*  Venues Data  */

insert into Venues(vid, vName, vAddress, 
                   vCity, vState, vZip, vPhoneNum)
	values('V001', 'Marist College', '3399 North Rd',
	       'Poughkeepsie', 'NY', 12601, 8455753000);
		   
insert into Venues(vid, vName, vAddress, 
                   vCity, vState, vZip, vPhoneNum)
	values('V002', 'Collector Central', '48 Birch St',
	       'Poughkeepsie', 'NY', 12601, 8455253453);
		   
insert into Venues(vid, vName, vAddress, 
                   vCity, vState, vZip, vPhoneNum)
	values('V003', 'Best Comics', '900 Jericho Tpk',
	       'New Hyde Park', 'NY', 11040, 5166668237);
		   
insert into Venues(vid, vName, vAddress, 
                   vCity, vState, vZip, vPhoneNum)
	values('V004', 'Funko HQ', '2802 Wetmore Ave',
	       'Everett', 'WA', 98201, 2035167321);
		   

/* Meetings Data */

insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-08-14 17:30:00', 'V001', 'F001', 7,
	       'Welcome to our first meeting, plans and aspirations for the future of the club, trades');
		   
insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-08-28 13:00:00', 'V001', 'F002', 7,
	       'Building a database for the club');
		   
insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-09-12 20:15:00', 'V002', 'F009', 8,
	       'Where Funko went wrong with the new Stranger Things Pops');
		   
insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-09-18 17:30:00', 'V003', 'F008', 8,
	       'Marvel Pops');
		   
insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-09-25 16:15:00', 'V001', 'F003', 7,
	       'Big Debate: In-Box vs. Out-of-Box');
		   
insert into Meetings(whenMeet, vid, meetLeaderHID, numAttended, topics)
	values('2017-10-09 13:45:00', 'V004', 'F001', 7,
	       'The best field trip ever!');
		   

		   
/*  Views  */

create view chasingValue as
select pid, pName
from Pops
where chase = true;

--select * from chasingValue;

create view ooB as
select hm.fName, hm.lName, hm.email
from Humans as hm, Members as mem
where mem.hid = hm.hid
and mem.boxPref = 'out';

--select * from ooB;

create view whoLead as
select mt.whenMeet, hm.fName, hm.lName
from Humans as hm, Meetings as mt
where hm.hid = mt.meetLeaderHID;

--select * from whoLead;


/*  Reports  */

select round(avg(cast(purchPrice as decimal)),2) as CharliesAvgPriceAfterSchoolStarted
from F001
where purchDate > '2017-09-01';

select sum(qty) as AlansTotalPurchasedBefore2016
from F002
where purchDate < '2016-01-01';


/*  Stored Proceedures */

drop function memberInfo(varchar(4), REFCURSOR)
create or replace function memberInfo(VARCHAR(4), REFCURSOR) returns REFCURSOR as
$$
declare
	humanID     VARCHAR(4)     := $1;
	resultSet   REFCURSOR      := $2;
	
begin
	open resultSet for
		select hm.hid, hm.fName, hm.lName, hm.phoneNum, 
		       mem.boxPref, mem.firstPop, mem.favPop
		from humans as hm, members as mem
        where hm.hid = mem.hid
        and hm.hid = humanID;
	return resultSet;
end;
$$
language plpgsql;

select memberInfo('F005', 'results');
fetch all from results;



drop function meetInfo(varchar(4), REFCURSOR)
create or replace function meetInfo(VARCHAR(4), REFCURSOR) returns REFCURSOR as
$$
declare
	venueID     VARCHAR(4)     := $1;
	resultSet   REFCURSOR      := $2;
	
begin
	open resultSet for
		select mt.whenMeet, vn.vName, vn.vphoneNum, mt.topics
		from meetings as mt, venues as vn
        where mt.vid = vn.vid
        and mt.vid = venueID;
	return resultSet;
end;
$$
language plpgsql;

select meetInfo('V001', 'results');
fetch all from results;


/*  Trigger  */

create or replace function addHuman() returns trigger as
$$
     begin 
        if new.hid is null then 
          raise exception 'Invalid hid';
        end if;
        if new.dob is null then
          raise exception 'Invalid DOB';
        end if;
        insert into Humans(hid, fName, lName, dob,
                            address, city, state, zip,
                            phoneNum, email)
                    values (new.hid, new.fName, new.lName, new.dob, new.address, 
                             new.city, new.state, new.zip, new.phoneNum, new.email);
        return new;
      end;
$$ language plpgsql;

create trigger addHuman
after insert on Humans
for each row execute procedure addHuman();


/*  User Roles  */

create roll admin;
create roll secretary
create roll F001;
create roll F002;
create roll F003;
create roll F004;
create roll F005;
create roll F006;
create roll F007;



grant all on all tables in schema public to admin; 

grant select, insert, update, delete on Meetings to secretary;
grant select, insert, update, delete on Venues to secretary;
grant select, insert, update, delete on Pops to secretary;
grant select, insert, update, delete on Humans to secretary;
grant select, insert, update, delete on Members to secretary;
grant select, insert, update, delete on Guests to secretary;

grant select, insert, update, delete on F001 to F001;
grant select, insert, update, delete on F002 to F002;
grant select, insert, update, delete on F003 to F003;
grant select, insert, update, delete on F004 to F004;
grant select, insert, update, delete on F005 to F005;
grant select, insert, update, delete on F006 to F006;

