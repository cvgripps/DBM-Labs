drop table if exists people;
drop table if exists actors;
drop table if exists directors;
drop table if exists spouses;
drop table if exists movies;
drop table if exists castCrew;


/* People Table */
create table people (
		pid             char(4) unique not null,
        fName           text not null,
        lName           text not null,
        birthday        date not null,
        heightIN		integer not null,
        weightLBS		integer not null,
        favColor		text,
        address			text not null,
        hairColor		text not null,
        eyeColor		text not null,
        primary key (pid)
);        

/* People Data */

insert into people (pid, fName, lName, birthday, heightIN,
                   weightLBS, favColor, address, hairColor, eyeColor)
             Values ('a001', 'Alan', 'Labouseur', '1975-05-13', '72', '193',
                    'Red', '3399 North Rd, Poughkeepsie, NY 12601', 'Brown', 'Blue'); 
                    --sorry for telling lies, but I did not have this information!

insert into people (pid, fName, lName, birthday, heightIN,
                   weightLBS, favColor, address, hairColor, eyeColor)
             Values ('a002', 'Charlie', 'Grippaldi', '1997-01-06', '68', '230',
                    'Blue', '19 Poplar St, Poughkeepsie, NY 12601', 'Green', 'Blue'); 
                    
insert into people (pid, fName, lName, birthday, heightIN,
                   weightLBS, favColor, address, hairColor, eyeColor)
             Values ('a003', 'Danny', 'DeVito', '1944-11-17', '58', '150',
                    'Orange', '132 Clove St, Asbury Park, NJ 84929', 'Brown', 'Brown');      

insert into people (pid, fName, lName, birthday, heightIN,
                   weightLBS, favColor, address, hairColor, eyeColor)
             Values ('a004', 'Billie Joe', 'Armstrong', '1972-02-17', '71', '184',
                    'Green', '924 Gilman St, Oakland, CA 94611', 'Black', 'Brown');
                    
select * from people;

/* Actors */
create table actors (
			pid			char(4) not null references people(pid),
			AGAD		date,
			primary key(pid)
);



insert into  actors (pid, AGAD)
	values ('a002', '2007-04-23');
    
insert into  actors (pid, AGAD)
	values ('a003', '1987-11-01');
    
insert into  actors (pid, AGAD)
	values ('a004', '1993-02-17');    
    
select * from actors;    




/* Directors */

create table directors(
		pid				char(4) not null references people(pid),
		filmSchool		text,
		DGAD			date,
		faveLenseMaker	text,
		primary key (pid)
);


insert into directors (pid, filmSchool, DGAD, faveLenseMaker)
		values ('a001', 'Best School', '1990-06-18', 'Gripp Labs');
        
insert into directors (pid, filmSchool, DGAD, faveLenseMaker)
		values ('a004', 'Cali Film', '2001-10-05', 'Lense Tech');        

select * from directors;


/* Spouses */

create table spouses(
		pid			char(4) not null references people(pid),
		sfName		text not null,
		slName		text not null,
		primary key(pid)
);


insert into spouses (pid, sfName, slName)
	values('a001', 'Missus', 'Labouseur');
    
insert into spouses (pid, sfName, slName)
	values('a004', 'Adrienne', 'Armstrong'); 
    
select * from spouses;

/* Movies */
create table movies (
		mid			char(2) not null,
		mpaaNum		varchar(4) not null,
		name		text not null,
		releaseDate	date not null,
		dbosUSD		integer not null,
		fbosUSD		integer not null,
		dvdbluSales	integer not null,
		primary key (mid)
);

insert into movies (mid, mpaaNum, name, releaseDate, dbosUSD, fbosUSD, dvdbluSales)
	values('17', 'PG13', 'GoldenEye', '1995-11-17', '100500300', '83000200', '7202025');

insert into movies (mid, mpaaNum, name, releaseDate, dbosUSD, fbosUSD, dvdbluSales)
	values('11', 'PG', 'Moonraker', '1979-06-29', '35819002', '2159009', '51244781');

insert into movies (mid, mpaaNum, name, releaseDate, dbosUSD, fbosUSD, dvdbluSales)
	values('01', 'PG', 'Dr. No', '1962-10-05', '1792000', '42050992', '10300600');
    
select * from movies;



create table castCrew (
		pid				char(4) not null references people (pid),
		mid				char(2) not null references movies (mid),
		role	    	text not null,
		primary key (mid)
);


insert into castCrew (pid, mid, role)
		values ('a002', '11', 'Director');
        
insert into castCrew (pid, mid, role)
		values ('a001', '11', 'Actor');
        
insert into castCrew (pid, mid, role)
		values ('a004', '01', 'Director'); 
        
insert into castCrew (pid, mid, role)
		values ('a003', '01', 'Actor');  
        
insert into castCrew (pid, mid, role)
		values ('a002', '17', 'Actor');  

insert into castCrew (pid, mid, role)
		values ('a003', '17', 'Director');
        
select * from castCrew;     


/* 3. Functional dependencies for each table 

People
PID ==> fName, lName, birthday, heightIN, weightLBS,
		favColor, address, hairColor, eyeColor

Actors
PID ==> AGAD

Directors
PID ==> filmSchool, DGAD, faveLenseMaker

Spouses
PID ==> sfName, slName

Movies
MID ==> mpaaNum, name, releaseDate, dbosUSD,
		fbosUSD, dvdbluSales
		
Cast & Crew
MID ==> PID, role		
		
		


*/



/* 4. Write a query to show all the directors with whom
actor "Alan  Labouseur" has worked. */

select * 
from people p,directors d 
where p.pid = d.pid 
      and p.pid != 'a001'
      and d.pid 
      in (select pid 
	  from castCrew 
	  where role = 'Director' 
	  and mid 
	  in (select mid 
	  from castCrew 
      where pid = 'a001'));